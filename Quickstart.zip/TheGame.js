/* API
IMPORTANT!! - Everything you write will be run immediately and in order, this means that even if you define the gameLoop before something else, that something will run before your gameLoop is called

Vector2d(x,y): x,y
- add(b) 
- sub(b) 
- dot(b) 
- length() 
- distance(b) 
- normalise(): returns new Vector2d

Vector3d(x,y,z): x,y,z 
- add(b) 
- sub(b) 
- dot(b) 
- length() 
- distance(b) 
- normalise(): returns new Vector3d;

Character(pos,speed,spriteList): pos - vector3d, speed - number, spriteList - list of sprites that the character uses, the first four are for up, down, left and right with the rest being stored in an internal list called sprites, d - direction (string), tanimation - internal object that either has a value of "none" or it stores the timer and step of the active animation - the animation can be stopped by using the method named stopAnimation, there are four different sprites that are loaded into their own variables to ensure that there is no delay - spriteUp, spriteDown, spriteLeft and spriteRight
- move(up,down,left,right) - controls built in movement, simply provide which directions the character has impulses to move towards and the method will move the character in the correct direction
- teleport(newPosition - Vector3d, direction - sting (up,down,left,right)) - if one of the aformentioned directions are given it will give one move command to the character to align the sprite
- animation(spriteList, posList, stepSpeed - milliseconds) - starts an animation that will change frame every stepspeed milliseconds and every frame will be in the corresponding position and have the correspondin sprite
- stopAnimation() - stops the animation playing and resets tanimation

rect(x, y, size x, size y, color) - draws a rectangle to the screen with the corresponding coordinates, size, color and if color is equal to "clear" it will erase instead of draw

rect(pos - Vector2d, size - Vector2d, color) - previous instructions apply

circle(x, y, radius, color) - draws a circle with the corresponding options to the screen

circle(pos - Vector2d, radius, color, alpha) - previous instructions apply

circle(pos and radius - Vector3d, color, alpha) - previous instructions apply

text(x,y,text,size,color,font) - draws text at a specific coordinate, size, color and optionally a specific font such as the default which is Arial

line(x1,y1,x2,y2,width,color) - draws a line with the desired color and width from (x1,y1) to (x2,y2)

picture(x, y, size x, size y, image location, alpha) - loads and draws an image using its location relative to this file or from the root, heavily resource intensive as every time the function is used a complete image is loaded to memory

picture(pos - Vector2d, size - Vector2d, image location, alpha) - previous instructions apply

loadedPicture(x, y, size x, size y, picture, alpha) - draws a previously loaded image, works using the loadImage function to load an image into memory and put it inside of an object, then the image can be drawn using this function without using very many resources

loadedPicture(pos - Vector2d, size - Vector2d, picture,alpha) - previous instructions apply

loadImage(location, callback) - loads an image into memory and returns the object. Optional callback function can be given as an argument to be called when the image is finished loading.

clearScreen() - clears everything drawn to the screen before

stopUpdate() - stops the gameLoop from running, effectively 'killing' the game

There are a couple different objects, these are the ones I have defined such as:

canvas - contains width and height

ctx - context for the canvas and contains many functions that I have used for creating the drawing functions, search it up if you want to use advanced stuff

keyboard - contains every button's state unless it has not been pressed, in which case it will show undefined or null for that key.
*/

//Image loading place

const wUp=loadImage("Images/walkUp.png");
const wDown=loadImage("Images/walkDown.png");
const wLeft=loadImage("Images/walkLeft.png");
const wRight=loadImage("Images/walkRight.png");

/*
Defines new objects called player and enemy with a position, of x:600, y:150 and z:1, the player character has a speed of 5 and the enemy a speed of 3 and the preloaded images have been put inside of a list that the characters automatically use for up, down, left and right.
*/
const player=new Character(new Vector3d(600,150,1),5,[wUp,wDown,wLeft,wRight]);
const enemies=[];
enemies.push(new Character(new Vector3d(Math.random()<=0.5?-100:canvas.width+100,Math.random()<=0.5?-100:canvas.height+100,1),Math.random()*2.5+2,[wUp,wDown,wLeft,wRight]));

/*
The gameLoop function; anything written inside it will repeat every 16+2/3 ms by default, but you can redefine the speed by entering a new number into the global variable called updateSpeed.
*/
function gameLoop(){
    clearScreen();
    // Draws stuff to the screen
    rect(10,10,100,200,"red");
    rect(new Vector2d(200,100),new Vector2d(200,100),"blue");
    circle(400,50,10,"red");
    circle(new Vector2d(500,50),20,"green");
    circle(new Vector3d(600,50,30),"blue");

    // Character movement
    player.move(keyboard.w && player.p.y> -10,keyboard.s && player.p.y< canvas.height-100,keyboard.a && player.p.x> -25,keyboard.d && player.p.x<canvas.width-75);
    //Conditionals inside the arguments that automatically returns true or false
    for(const enemy of enemies){
        enemy.move(enemy.p.y>player.p.y+3 && enemy.p.y> -10,enemy.p.y<player.p.y-3 && enemy.p.y<canvas.height-100,enemy.p.x>player.p.x+3 && enemy.p.x> -25,enemy.p.x<player.p.x-3 && enemy.p.x<canvas.width-75);
    };

    // Checks if you are pressing specific buttons and in that case if an animation is already playing, if the conditionals both evaluate to true it plays the animation, could be shortened by storing the sprites and etc inside of lists, but I don't have time for that
    if(keyboard.enter){
        enemies.push(new Character(new Vector3d(Math.random()<=0.5?-100:canvas.width+100,Math.random()<=0.5?-100:canvas.height+100,1),Math.random()*2.5+2,[wUp,wDown,wLeft,wRight]));
    };

    // Checks if the player is behind or in front of the enemy to make sure that the layering is correct, I could probably do it better but I don't have time for that
    for(const enemy of enemies){
        if(enemy.p.y<=player.p.y) loadedPicture(enemy.p.x,enemy.p.y,100,100,enemy.sprite,0.5);
    };
    loadedPicture(player.p.x,player.p.y,100,100,player.sprite);
    for(const enemy of enemies){
        if(enemy.p.y>player.p.y) loadedPicture(enemy.p.x,enemy.p.y,100,100,enemy.sprite,0.5);
    };
    // Draws text to the screen
    text(10,22,keyboard.m,20,"black");
    // If the enemy is close enough it will "kill" the game
    for(const enemy of enemies){
        if(player.p.distance(enemy.p)<=30) stopUpdate();
    };
    // Manual stop
    if(keyboard.arrowleft && keyboard.enter){
        clearScreen();
        stopUpdate();
    };
};