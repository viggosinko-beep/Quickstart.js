//File-name = Variables.js
const body=document.body;
body.style="overflow:hidden;margin:0px;text-align:center;padding:0px;"
const canvas=document.getElementById("CNVS");
canvas.style="text-align:center;padding:0px;margin:0px;overflow:hidden;border:none;";
const ctx=canvas.getContext("2d");
let keyboard={};
document.addEventListener('keydown', function(event) {
    keyboard[event.key.toLowerCase()]=true;
});
document.addEventListener('keyup', function(event) {
    keyboard[event.key.toLowerCase()]=false;
});
canvas.width=window.innerWidth;
canvas.height=window.innerHeight;