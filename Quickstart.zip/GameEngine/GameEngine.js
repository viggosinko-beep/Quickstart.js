//File-name = GameEngine.js
class Vector2d{
    constructor(x,y){
        this.x=x;
        this.y=y;
    };
    add(b){
        return(new Vector2d(this.x+b.x,this.y+b.y));
    };
    sub(b){
        return(new Vector2d(this.x-b.x,this.y-b.y));
    };
    dot(b){
        return(this.x*b.x+this.y*b.y);
    };
    length(){
        return(Math.sqrt(this.x**2+this.y**2));
    };
    distance(b){
        return(Math.sqrt((this.x-b.x)**2+(this.y-b.y)**2));
    }
    normalise(){
        const len=this.length();
        return(new Vector2d(len==0?0:this.x/len,len==0?0:this.y/len));
    };
};

class Vector3d{
    constructor(x,y,z){
        this.x=x;
        this.y=y;
        this.z=z;
    };
    add(b){
        return(new Vector3d(this.x+b.x,this.y+b.y,this.z+b.z));
    };
    sub(b){
        return(new Vector3d(this.x-b.x,this.y-b.y,this.z-b.z));
    };
    dot(b){
        return(this.x*b.x+this.y*b.y+this.z*b.z);
    };
    length(){
        return(Math.sqrt(this.x**2+this.y**2+this.z**2));
    };
    distance(b){
        return(Math.sqrt((this.x-b.x)**2+(this.y-b.y)**2+(this.z-b.z)**2));
    }
    normalise(){
        const len=this.length();
        return(new Vector3d(len==0?0:this.x/len,len==0?0:this.y/len,len==0?0:this.z/len));
    };
};

class Character{
    constructor(p,speed,spriteList){
        this.p=p;
        this.d="up";
        this.speed=speed
        this.spriteUp=spriteList[0];
        this.spriteDown=spriteList[1];
        this.spriteLeft=spriteList[2];
        this.spriteRight=spriteList[3];
        this.sprite=spriteList[0];
        this.tanimation="none";
        this.sprites=spriteList.slice(4);
    };
    #moveUp(){
        if(this.tanimation!="none") return;
        this.d="up";
        this.p=this.p.add(new Vector3d(0,-this.speed,0));
        this.sprite=this.spriteUp;
    };
    #moveDown(){
        if(this.tanimation!="none") return;
        this.d="down";
        this.p=this.p.add(new Vector3d(0,this.speed,0));
        this.sprite=this.spriteDown;
    };
    #moveLeft(){
        if(this.tanimation!="none") return;
        this.d="left";
        this.p=this.p.add(new Vector3d(-this.speed,0,0));
        this.sprite=this.spriteLeft;
    };
    #moveRight(){
        if(this.tanimation!="none") return;
        this.d="right";
        this.p=this.p.add(new Vector3d(this.speed,0,0));
        this.sprite=this.spriteRight;
    };
    #moveUL(){
        if(this.tanimation!="none") return;
        this.d="upLeft";
        const nSpeed=Math.sqrt(this.speed**2/2)
        this.p=this.p.add(new Vector3d(-nSpeed,-nSpeed,0));
        this.sprite=this.spriteUp;
    };
    #moveUR(){
        if(this.tanimation!="none") return;
        this.d="upRight";
        const nSpeed=Math.sqrt(this.speed**2/2)
        this.p=this.p.add(new Vector3d(nSpeed,-nSpeed,0));
        this.sprite=this.spriteRight;
    };
    #moveDL(){
        if(this.tanimation!="none") return;
        this.d="downLeft";
        const nSpeed=Math.sqrt(this.speed**2/2)
        this.p=this.p.add(new Vector3d(-nSpeed,nSpeed,0));
        this.sprite=this.spriteLeft;
    };
    #moveDR(){
        if(this.tanimation!="none") return;
        this.d="downRight";
        const nSpeed=Math.sqrt(this.speed**2/2)
        this.p=this.p.add(new Vector3d(nSpeed,nSpeed,0));
        this.sprite=this.spriteDown;
    };
    teleport(newPos,dir){
        this.p=newPos;
        switch(dir){
            case "up":
                this.#moveUp();
                break;
            case "down":
                this.#moveDown();
                break;
            case "left":
                this.#moveLeft();
                break;
            case "right":
                this.#moveRight();
        };
    };
    #animationStep(newPos,newSprite){
        this.p=newPos;
        this.sprite=newSprite;
    };
    stopAnimation(){
        clearInterval(this.tanimation.timer);
        this.tanimation="none";
    };
    #doAnimation(spriteList,newPositions){
        this.#animationStep(newPositions[this.tanimation.step],spriteList[this.tanimation.step])
        if(this.tanimation.step>=spriteList.length-1){this.stopAnimation(); return;};
        this.tanimation.step+=1
    };
    animation(spriteList,posList,stepSpeed){
        this.tanimation={timer:setInterval(() => this.#doAnimation(spriteList,posList), stepSpeed),step:0}
        this.#doAnimation(spriteList,posList);
    };
    move(u,d,l,r){
        if(u && !(l || r) || u && l && r) this.#moveUp();
        if(d && !(l || r) || d && l && r) this.#moveDown();
        if(l && !(u || d) || l && u && d) this.#moveLeft();
        if(r && !(u || d) || r && u && d) this.#moveRight();
        if(u && l && !r) this.#moveUL();
        if(u && r && !l) this.#moveUR();
        if(d && l && !r) this.#moveDL();
        if(d && r && !l) this.#moveDR();
    }
};

function rect(x,y,sx,sy,c){
    if((x instanceof Vector2d) && (y instanceof Vector2d) && isNaN(sx)){
        const xx=x;
        const yy=y;
        const ssx=sx;
        x=xx.x;
        y=xx.y;
        sx=yy.x;
        sy=yy.y;
        c=ssx;
    };
    switch(c){
        case "clear":
        case null:
            ctx.clearRect(x,y,sx,sy);
            break;
        default:
            ctx.fillStyle=c;
            ctx.fillRect(x,y,sx,sy);
    };
};

function circle(x,y,r,c){
    if((x instanceof Vector2d) && !isNaN(y) && isNaN(r)){
        const xx=x;
        const yy=y;
        const rr=r;
        x=xx.x;
        y=xx.y;
        r=yy;
        c=rr;
    };
    if((x instanceof Vector3d) && isNaN(y)){
        const xx=x;
        const yy=y;
        x=xx.x;
        y=xx.y;
        r=xx.z;
        c=yy;
    };
    ctx.beginPath();
    ctx.arc(x,y,r,0,2*Math.PI);
    ctx.fillStyle=c;
    ctx.fill();
};

function picture(x,y,sx,sy,src,alpha){
    if((x instanceof Vector2d) && (y instanceof Vector2d) && isNaN(sx)){
        const xx=x;
        const yy=y;
        const ssx=sx;
        const ssy=sy;
        x=xx.x;
        y=xx.y;
        sx=yy.x;
        sy=yy.y;
        src=ssx;
        alpha=ssy;
    };
    if(isNaN(alpha)) alpha=1;
    const img=new Image();
    img.src=src;
    img.onload = () => {
        ctx.globalAlpha=alpha;
        ctx.drawImage(img,x,y,sx,sy);
        ctx.globalAlpha=1;
    };
};
function text(x,y,text,size,color,font){
    if(!font) font="Arial";
    ctx.font=size+"px "+font;
    ctx.fillStyle=color;
    ctx.fillText(text,x,y);
};
function loadedPicture(x,y,sx,sy,pic,alpha){
    if((x instanceof Vector2d) && (y instanceof Vector2d) && isNaN(sx)){
        const xx=x;
        const yy=y;
        const ssx=sx;
        const ssy=sy;
        x=xx.x;
        y=xx.y;
        sx=yy.x;
        sy=yy.y;
        pic=ssx;
        alpha=ssy;
    };
    if(isNaN(alpha)) alpha=1;
    ctx.globalAlpha=alpha;
    ctx.drawImage(pic,x,y,sx,sy);
    ctx.globalAlpha=1;
};
function clearScreen(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
};
function loadImage(location){
    let image=new Image();
    image.src=location;
    return(image);
}
let timer;
function setTimer(t){timer=t;};
function stopUpdate(){
    clearInterval(timer);
}
function stopTimer(timer){clearInterval(timer);};
let updateSpeed=16+2/3;