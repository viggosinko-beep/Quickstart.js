//File-name = Boot.js
if(gameLoop!= null) setTimer(setInterval(gameLoop,updateSpeed));